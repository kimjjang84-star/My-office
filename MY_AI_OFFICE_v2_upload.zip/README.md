# MY AI OFFICE v2

대표가 AI 비서실장에게 업무를 지시하면 전문 AI 팀원이 역할을 나누어 결과물을 작성하고, 대표가 검토·승인하는 **개인용 AI 회사형 웹서비스**입니다. 기존 대시보드 디자인을 유지한 실행 가능한 MVP입니다.

## 현재 구현된 기능

- 개인 비밀번호 로그인, HTTP-only 세션 쿠키, 동일 출처 요청 검사, 로그인 시도 제한
- 대시보드, AI 직원 CRUD, 프로젝트 생성, 업무 목록, 업무 히스토리 (브라우저 로컬 저장)
- 비서실장 자동 분배 또는 특정 팀원 지정, 전문 팀원 최대 3명 순차 협업
- OpenAI Responses API를 이용한 실제 텍스트/보고서 생성 (서버 API 키 필요)
- 리서치 담당의 OpenAI hosted web_search (활성 시 별도 사용료 발생)
- 비서실장 통합 보고서, 근거 URL, 각 팀원별 기여 내용, 토큰 사용량
- 업무 중단, 실패 표시, 대표 검토·수정 요청·최종 승인
- PC/모바일 대응, GitHub 커밋 시 Render 자동 배포 설정 가능

## 아직 지원하지 않는 기능

- 이미지 및 벡터 파일 실제 생성, 이메일/공모전 자동 제출, 채용 지원, 정기 자동 실행
- 여러 기기의 데이터를 동기화하는 DB 및 조직별 사용자/권한 관리
- 서버 재시작 이후 진행 중 AI 작업 복원, 영구적인 서버 작업 큐, 정확한 비용 청구 계산
- OpenAI API 키 없는 상태의 실제 AI 답변

**중요:** 데이터는 현재 각 기기의 브라우저 `localStorage`에 보관됩니다. 사용 중인 브라우저의 데이터를 삭제하면 업무 내용도 사라질 수 있으므로 중요한 보고서는 복사해 별도로 보관하세요. AI 실행 과정에서 생성한 임시 기록은 Render 무료 인스턴스가 재시작하면 사라질 수 있습니다.

## 로컬 실행

Node.js 20 이상이면 추가 패키지 설치 없이 실행됩니다.

```bash
# Linux/Mac (로컬 테스트용 예시 비밀번호, 실서비스에 사용하지 마세요)
export APP_PASSWORD='CHANGE_ME_PRIVATE_PASSWORD'
export APP_SESSION_SECRET='CHANGE_ME_TO_RANDOM_SECRET_AT_LEAST_32_CHARACTERS'
export OPENAI_API_KEY=''
export OPENAI_MODEL='gpt-5.4-mini'
node server.js
```

로컬 접속: http://localhost:10000

테스트: `npm test`

## Render에 실제 배포하기

### A. GitHub 저장소 업데이트

기존 GitHub 저장소: https://github.com/kimjjang84-star/My-office

1. `MY_AI_OFFICE_v2_upload.zip` 압축을 **먼저 해제**합니다.
2. 저장소 `Add file → Upload files`로 압축을 푼 파일 중 `index.html`, `server.js`, `package.json`, `README.md`, `.gitignore`를 저장소 **최상위**에 업로드합니다. `test/` 폴더는 선택 사항입니다.
3. `Commit changes`를 눌러 `main` 브랜치에 반영합니다.

> 기존 Render **Static Site**에서는 변경된 화면이 시뮬레이션 모드로 동작합니다. AI 실행은 아래 별도 Node **Web Service**가 필요합니다. 기존 Static Site를 먼저 삭제할 필요는 없습니다.

### B. Render 무료 Web Service 만들기

1. https://dashboard.render.com/ → `New` → `Web Service`.
2. `kimjjang84-star/My-office` 저장소와 `main` 브랜치를 선택합니다.
3. `Name`: `my-ai-office-app` (중복이면 다른 이름)
4. `Runtime`: **Node**, `Plan`: **Free**, `Region`: Singapore (선택 가능할 때)
5. `Build command`: `npm install` 또는 `npm ci`(lockfile 있을 때)
6. `Start command`: `node server.js`
7. `Environment Variables`를 아래와 같이 설정합니다. **키와 비밀번호를 GitHub 파일에 작성하지 마세요.**

| Key | Value |
|---|---|
| `APP_PASSWORD` | 대표 본인만 아는 길고 강한 로그인 비밀번호 |
| `APP_SESSION_SECRET` | 임의의 32자 이상 비밀 문자열 (서로 다른 비밀번호 사용) |
| `OPENAI_API_KEY` | OpenAI Platform에서 발급한 API 키 |
| `OPENAI_MODEL` | `gpt-5.4-mini` (계정에서 사용 가능한 모델로 변경 가능) |
| `ALLOW_WEB_SEARCH` | `true` 또는 `false` |
| `NODE_ENV` | `production` |

8. `Deploy Web Service` 후 Render가 발급한 URL을 열어 로그인합니다.
9. `업무 지시 → 비서실장 → 업무 실행 → 검토 → 승인`으로 테스트합니다.

`OPENAI_API_KEY`를 아직 발급받지 않았다면 설정하지 않아도 사이트 로그인 및 업무 관리까지는 동작하지만, **AI 실행은 비활성**으로 표시됩니다. API는 ChatGPT Plus 구독과 별도로 비용이 청구됩니다.

## 기존 사이트와 차이

- 기존 Static Site URL: `https://my-ai-office-gu7a.onrender.com` (기존 시제품/정적 화면)
- 새 Render Web Service URL: Render가 **새로 발급**하는 `onrender.com` 주소 (로그인 및 AI 실행)

기존 URL이 자동으로 새 Web Service로 변경되지 않습니다. 새 서비스를 정상 검증한 뒤 원하는 주소/도메인으로 전환하세요.

## 보안 및 운영 주의

- API 키는 반드시 Render 환경변수에 저장하고 `index.html`/GitHub에 포함하지 않습니다.
- 데모가 아닌 서비스를 인터넷에 공개하기 전에 `APP_PASSWORD`, `APP_SESSION_SECRET`을 반드시 설정합니다. 설정되지 않으면 서버가 로그인 기능을 거부합니다.
- OpenAI 모델에 전달하는 업무 내용과 전문 팀원 지침에 개인식별정보, 금융정보, 비밀번호 등을 넣지 마세요.
- 조사 결과에 포함된 웹 문서는 신뢰하지 않는 외부 입력입니다. 최종 결과의 링크·날짜·자격 요건을 직접 검증하세요.
- AI 도구 호출에는 비용이 발생할 수 있습니다. 최대 전문 팀원 3명, 동시 업무 1건, 팀원별 출력 토큰 상한을 코드에서 제한하지만 이것이 **확정된 금액 상한을 보장하지는 않습니다.** OpenAI Platform의 프로젝트별 사용 한도를 별도로 설정하세요.
- 무료 Render Web Service는 비활성 시 슬립 상태가 될 수 있고, 진행 중 업무가 중단될 수 있습니다.
- 이메일 발송·공모전 제출·결제처럼 외부 영향이 있는 행동은 현재 구현하지 않았으며, 대표 승인 없는 자동 실행은 금지합니다.

## 주요 소스 구조

```text
index.html        브라우저 대시보드, 작업 등록, 검토/승인, 로그인
server.js         로그인/인증, AI 팀원 오케스트레이션, OpenAI API 프록시
package.json      npm start / npm test
README.md         사용·배포 안내
.env.example      환경변수 이름 예시 (실제 비밀 값 없음)
test/             Node 서버 최소 기능 테스트
```
