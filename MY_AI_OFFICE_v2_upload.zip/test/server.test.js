'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const {spawn}=require('node:child_process');
const {selectAgents,extractText,extractCitations,execute}=require('../server');

const agents=[{id:'ceoai',name:'한실장',role:'실장'}, {id:'research',name:'박리서치',role:'조사'}, {id:'plan',name:'김기획',role:'기획'}, {id:'design',name:'이디자인',role:'디자인'}, {id:'marketing',name:'최마케팅',role:'마케팅'}];
test('manager delegates contest to research, planning and design',()=>{
 assert.deepEqual(selectAgents('디자인 로고 공모전 조사와 전략기획','ceoai',agents).map(a=>a.id),['research','plan','design']);
});
test('explicit specialist requests only that agent',()=>{
 assert.deepEqual(selectAgents('로고 디자인 기획','marketing',agents).map(a=>a.id),['marketing']);
});
test('extract response text',()=>{
 assert.equal(extractText({output:[{content:[{type:'output_text',text:'테스트 보고서'}]}]}),'테스트 보고서');
});

async function startServer(env) {
 const port=14000+Math.floor(Math.random()*30000);
 const proc=spawn(process.execPath,['server.js'],{cwd:require('node:path').join(__dirname,'..'),env:{...process.env,PORT:String(port),...env},stdio:'ignore'});
 for(let i=0;i<40;i++){
  if(proc.exitCode!==null)throw new Error('Server process ended unexpectedly');
  try{const r=await fetch(`http://127.0.0.1:${port}/api/health`);if(r.ok)return {proc,base:`http://127.0.0.1:${port}`};}catch{}
  await new Promise(r=>setTimeout(r,100));
 }
 proc.kill();throw new Error('Server startup timeout');
}
test('HTTP unauthenticated endpoints reject requests and protect secrets',async()=>{
 const {proc,base}=await startServer({APP_PASSWORD:'localtestpassword123',APP_SESSION_SECRET:'test-secret-at-least-32-bytes-long',OPENAI_API_KEY:''});
 try{
  const health=await fetch(base+'/api/health');assert.equal(health.status,200);
  const homepage=await fetch(base+'/');assert.equal(homepage.status,200);assert.match(await homepage.text(),/MY AI OFFICE/);
  const session=await fetch(base+'/api/session');assert.equal(session.status,401);
  const unauthorized=await fetch(base+'/api/jobs',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({title:'테스트',description:'업무 실행 테스트'})});assert.equal(unauthorized.status,401);
  const wrong=await fetch(base+'/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:'wrong'})});assert.equal(wrong.status,401);
  const login=await fetch(base+'/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:'localtestpassword123'})});assert.equal(login.status,200);
  const sessionCookie=login.headers.get('set-cookie');assert.match(sessionCookie,/HttpOnly/);
  const validSession=await fetch(base+'/api/session',{headers:{Cookie:sessionCookie.split(';')[0]}});assert.equal(validSession.status,200);const status=await validSession.json();assert.equal(status.aiConfigured,false);
  const missingApiKey=await fetch(base+'/api/jobs',{method:'POST',headers:{'Content-Type':'application/json',Cookie:sessionCookie.split(';')[0]},body:JSON.stringify({title:'테스트',description:'업무 실행 테스트',agents})});assert.equal(missingApiKey.status,503);
  const csrf=await fetch(base+'/api/logout',{method:'POST',headers:{'Content-Type':'application/json',Origin:'https://evil.example'},body:'{}'});assert.equal(csrf.status,403);
 } finally {proc.kill();}
});

test('AI team orchestration yields review with specialist report and approval wait',async()=>{
 const originalFetch=global.fetch;
 const calls=[];
 global.fetch=async(url,options)=>{
  if(!String(url).includes('/v1/responses'))return originalFetch(url,options);
  const body=JSON.parse(options.body);calls.push(body);
  return {ok:true,status:200,json:async()=>({output:[{content:[{type:'output_text',text:`응답 ${calls.length}`,annotations:[{url_citation:false,url:'https://example.org/source',title:'source'}]}]}],usage:{input_tokens:10,output_tokens:20}})};
 };
 try{
  const job={id:'test',title:'로고 공모전 조사와 디자인 기획',description:'공식 공고 조사 후 디자인 컨셉 작성',assigned:'ceoai',agents,plan:[],steps:[],events:[],citations:[],report:'',status:'queued',error:'',createdAt:Date.now(),updatedAt:Date.now(),usage:{input_tokens:0,output_tokens:0},controller:new AbortController()};
  await execute(job);
  assert.equal(job.status,'review');
  assert.equal(job.steps.length,3);
  assert.equal(job.report,'응답 4');
  assert.equal(calls.length,4);
  assert.equal(job.usage.input_tokens,40);
  assert.equal(job.citations[0].url,'https://example.org/source');
 }finally{global.fetch=originalFetch;}
});
